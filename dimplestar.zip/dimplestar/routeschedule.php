<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<title>Dimple Star Transport</title>
<link rel="stylesheet" type="text/css" href="style/style.css" />
<link rel="icon" href="images/icon.ico" type="image/x-con">
</head>
<body>
<div id="wrapper">
	<div id="header">
    <h1><a href="index.php"><img src="images/logo.png" class="logo" alt="Dimple Star Transport" /></a></h1>
        <ul id="mainnav">
			<li><a href="index.php">Home</a></li>
			<li><a href="about.php">About Us</a></li>
            <li><a href="terminal.php">Terminals</a></li>
			<li class="current"><a href="routeschedule.php">Routes / Schedules</a></li>
            <li><a href="contact.php">Contact</a></li>
			<li><a href="book.php">Book Now</a></li>
	</div>
    <div id="content">
    	<div id="gallerycontainer">
			<div style="margin:0 auto; padding:30px 20px 20px 20px; width:820px;">
				<div class="login">
						<div id="right">
							<?php
								session_start();
								if(isset($_SESSION['email'])){
									$email = $_SESSION['email'];
									echo "Welcome,". $email. "!";
									echo "<a href='logout.php'>Logout</a>";
								}
								if(empty($email)){
									echo "<a href='signlog.php'></a>.";
								}?>
						</div>
					</div>
				<div id="right">
					<h3><?php include_once("php_includes/date_time.php"); ?></h3>
				</div>
                <div style="margin-bottom: 40px;">
                    <img src="images/route.png" style="width: 100%; max-width: 820px; height: auto; display: block; margin: 0 auto 20px;" alt="Route Map">
                    <p style="text-align: center; color: #666; font-size: 16px; margin-bottom: 30px;">(All trips are vice versa)</p>
                </div>

                <div style="background: #fff; border-radius: 8px; box-shadow: 0 2px 4px rgba(0,0,0,0.1); overflow: hidden;">
                    <div style="background: #ECBD2F; padding: 15px 20px;">
                        <h2 style="color: #fff; font-size: 20px; margin: 0;">Regular Schedule</h2>
                    </div>
                    
                    <div style="padding: 20px;">
                        <table style="width: 100%; border-collapse: collapse;">
                            <thead>
                                <tr style="border-bottom: 2px solid #ECBD2F;">
                                    <th style="padding: 15px; text-align: left; color: #333; font-size: 16px; font-weight: bold;">Origin</th>
                                    <th style="padding: 15px; text-align: left; color: #333; font-size: 16px; font-weight: bold;">Schedule</th>
                                    <th style="padding: 15px; text-align: left; color: #333; font-size: 16px; font-weight: bold;">Destination</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr style="border-bottom: 1px solid #eee;">
                                    <td style="padding: 15px; color: #333; font-weight: 500;">Ali Mall Cubao Terminal</td>
                                    <td style="padding: 15px; color: #666;">
                                        <div style="display: flex; flex-wrap: wrap; gap: 8px;">
                                            <span style="background: #f8f8f8; padding: 4px 8px; border-radius: 4px;">9:00 am</span>
                                            <span style="background: #f8f8f8; padding: 4px 8px; border-radius: 4px;">10:00 am</span>
                                            <span style="background: #f8f8f8; padding: 4px 8px; border-radius: 4px;">1:00 pm</span>
                                            <span style="background: #f8f8f8; padding: 4px 8px; border-radius: 4px;">4:00 pm</span>
                                        </div>
                                    </td>
                                    <td style="padding: 15px; color: #333;">San Jose</td>
                                </tr>
                                <tr style="border-bottom: 1px solid #eee;">
                                    <td style="padding: 15px; color: #333; font-weight: 500;">Alabang Terminal</td>
                                    <td style="padding: 15px; color: #666;">
                                        <div style="display: flex; flex-wrap: wrap; gap: 8px;">
                                            <span style="background: #f8f8f8; padding: 4px 8px; border-radius: 4px;">6:00 am</span>
                                            <span style="background: #f8f8f8; padding: 4px 8px; border-radius: 4px;">7:00 am</span>
                                            <span style="background: #f8f8f8; padding: 4px 8px; border-radius: 4px;">2:00 pm</span>
                                            <span style="background: #f8f8f8; padding: 4px 8px; border-radius: 4px;">6:00 pm</span>
                                            <span style="background: #f8f8f8; padding: 4px 8px; border-radius: 4px;">10:00 pm</span>
                                        </div>
                                    </td>
                                    <td style="padding: 15px; color: #333;">San Jose</td>
                                </tr>
                                <tr style="border-bottom: 1px solid #eee;">
                                    <td style="padding: 15px; color: #333; font-weight: 500;">Cabuyao Terminal</td>
                                    <td style="padding: 15px; color: #666;">
                                        <div style="display: flex; flex-wrap: wrap; gap: 8px;">
                                            <span style="background: #f8f8f8; padding: 4px 8px; border-radius: 4px;">8:00 am</span>
                                            <span style="background: #f8f8f8; padding: 4px 8px; border-radius: 4px;">9:00 am</span>
                                            <span style="background: #f8f8f8; padding: 4px 8px; border-radius: 4px;">4:00 pm</span>
                                            <span style="background: #f8f8f8; padding: 4px 8px; border-radius: 4px;">8:00 pm</span>
                                        </div>
                                    </td>
                                    <td style="padding: 15px; color: #333;">San Jose</td>
                                </tr>
                                <tr style="border-bottom: 1px solid #eee;">
                                    <td style="padding: 15px; color: #333; font-weight: 500;">España Terminal</td>
                                    <td style="padding: 15px; color: #666;">
                                        <div style="display: flex; flex-wrap: wrap; gap: 8px;">
                                            <span style="background: #f8f8f8; padding: 4px 8px; border-radius: 4px;">4:30 am</span>
                                            <span style="background: #f8f8f8; padding: 4px 8px; border-radius: 4px;">5:30 am</span>
                                            <span style="background: #f8f8f8; padding: 4px 8px; border-radius: 4px;">12:00 am</span>
                                            <span style="background: #f8f8f8; padding: 4px 8px; border-radius: 4px;">4:00 pm</span>
                                            <span style="background: #f8f8f8; padding: 4px 8px; border-radius: 4px;">8:00 pm</span>
                                        </div>
                                    </td>
                                    <td style="padding: 15px; color: #333;">San Jose</td>
                                </tr>
                                <tr style="border-bottom: 1px solid #eee;">
                                    <td style="padding: 15px; color: #333; font-weight: 500;">San Lazaro Terminal</td>
                                    <td style="padding: 15px; color: #666;">
                                        <div style="display: flex; flex-wrap: wrap; gap: 8px;">
                                            <span style="background: #f8f8f8; padding: 4px 8px; border-radius: 4px;">3:00 am</span>
                                            <span style="background: #f8f8f8; padding: 4px 8px; border-radius: 4px;">4:30 am</span>
                                            <span style="background: #f8f8f8; padding: 4px 8px; border-radius: 4px;">11:00 am</span>
                                            <span style="background: #f8f8f8; padding: 4px 8px; border-radius: 4px;">3:00 pm</span>
                                            <span style="background: #f8f8f8; padding: 4px 8px; border-radius: 4px;">7:00 pm</span>
                                        </div>
                                    </td>
                                    <td style="padding: 15px; color: #333;">San Jose</td>
                                </tr>
                                <tr>
                                    <td style="padding: 15px; color: #333; font-weight: 500;">Pasay Terminal</td>
                                    <td style="padding: 15px; color: #666;">
                                        <div style="display: flex; flex-wrap: wrap; gap: 8px;">
                                            <span style="background: #f8f8f8; padding: 4px 8px; border-radius: 4px;">5:00 am</span>
                                            <span style="background: #f8f8f8; padding: 4px 8px; border-radius: 4px;">6:00 am</span>
                                            <span style="background: #f8f8f8; padding: 4px 8px; border-radius: 4px;">1:00 pm</span>
                                            <span style="background: #f8f8f8; padding: 4px 8px; border-radius: 4px;">3:00 pm</span>
                                        </div>
                                    </td>
                                    <td style="padding: 15px; color: #333;">San Jose</td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
				<div class="column-clear"></div>
            </div>
				<div class="clearfix"></div>
        </div>
    </div>
    
<div id="footer">
	<a href="index.php"><img src="images/footer-logo.jpg" alt="Dimple Star Transport" /></a>
	<p>&copy;Dimple Star Transport<br /></p>
</div>

</div>
</body>
</html>