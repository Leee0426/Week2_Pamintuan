<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<title>Dimple Star Transport</title>
<link rel="stylesheet" type="text/css" href="style/style.css" />
<link rel="icon" href="images/icon.ico" type="image/x-con">
<style>
.contact-container {
    max-width: 1000px;
    margin: 0 auto;
    padding: 30px 20px;
}

.contact-grid {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 40px;
    margin-top: 30px;
}

.contact-info {
    background: #fff;
    padding: 30px;
    border-radius: 8px;
    box-shadow: 0 2px 4px rgba(0,0,0,0.1);
}

.contact-info h2 {
    color: #333;
    font-size: 24px;
    margin-bottom: 20px;
    border-bottom: 2px solid #ECBD2F;
    padding-bottom: 10px;
}

.contact-info p {
    color: #666;
    font-size: 16px;
    line-height: 1.6;
    margin: 10px 0;
}

.contact-info i {
    color: #ECBD2F;
    margin-right: 10px;
    width: 20px;
    display: inline-block;
}

.contact-form {
    background: #fff;
    padding: 30px;
    border-radius: 8px;
    box-shadow: 0 2px 4px rgba(0,0,0,0.1);
}

.contact-form h2 {
    color: #333;
    font-size: 24px;
    margin-bottom: 20px;
    border-bottom: 2px solid #ECBD2F;
    padding-bottom: 10px;
}

.form-group {
    margin-bottom: 20px;
}

.form-group label {
    display: block;
    color: #333;
    margin-bottom: 8px;
    font-weight: 500;
}

.form-group input,
.form-group textarea {
    width: 100%;
    padding: 12px;
    border: 1px solid #ddd;
    border-radius: 4px;
    font-size: 15px;
    transition: border-color 0.3s;
}

.form-group input:focus,
.form-group textarea:focus {
    border-color: #ECBD2F;
    outline: none;
}

.submit {
    background: #ECBD2F;
    color: white;
    padding: 12px 30px;
    border: none;
    border-radius: 4px;
    font-size: 16px;
    cursor: pointer;
    transition: background-color 0.3s;
}

.submit:hover {
    background: #d4a618;
}

.welcome-bar {
    background: #f8f8f8;
    padding: 10px 20px;
    border-radius: 4px;
    margin-bottom: 20px;
    display: flex;
    justify-content: space-between;
    align-items: center;
}

.welcome-bar .date-time {
    color: #666;
}

@media (max-width: 768px) {
    .contact-grid {
        grid-template-columns: 1fr;
    }
}
</style>

</head>
<body>
<div id="wrapper">
	<div id="header">
    <h1><a href="index.php"><img src="images/logo.png" class="logo" alt="Dimple Star Transport" /></a></h1>
        <ul id="mainnav">
			<li><a href="index.php">Home</a></li>
			<li><a href="about.php">About Us</a></li>
            <li><a href="terminal.php">Terminals</a></li>
			<li><a href="routeschedule.php">Routes / Schedules</a></li>
            <li class="current"><a href="contact.php">Contact</a></li>
			<li><a href="book.php">Book Now</a></li>
    	</ul>
	</div>
    <div id="content">
    	<div id="gallerycontainer">
            <div class="contact-container">
                <div class="welcome-bar">
                    <div class="user-info">
                        <?php
                            session_start();
                            if(isset($_SESSION['email'])){
                                $email = $_SESSION['email'];
                                echo "<span>Welcome, " . $email . "!</span>";
                                echo "<a href='logout.php' style='margin-left: 15px; color: #ECBD2F;'>Logout</a>";
                            }
                            if(empty($email)){
                                echo "<a href='signlog.php'></a>";
                            }
                        ?>
                    </div>
                    <div class="date-time">
                        <?php include_once("php_includes/date_time.php"); ?>
                    </div>
                </div>

                <h1 style="text-align: center; color: #333; margin-bottom: 30px;">Get in Touch</h1>

                <div class="contact-grid">
                    <div class="contact-info">
                        <h2>Contact Information</h2>
                        <p><i>📍</i> Dimple Star Transport</p>
                        <p style="padding-left: 30px;">Block 1 lot 10, Southpoint Subd.<br>
                        Brgy Banay-Banay, Cabuyao, Laguna</p>
                        <p><i>📞</i> 0929 209 0712</p>
                        <p><i>🕒</i> Operating Hours: 24/7</p>
                        <p><i>✉️</i> info@dimplestar.com</p>
                    </div>

                    <div class="contact-form">
                        <h2>Send us a Message</h2>
                        <form class="validate" action="messageexec.php" method="POST">
                            <div class="form-group">
                                <label for="name" class="required">Name</label>
                                <input id="name" type="text" name="name" required />
                            </div>
                            
                            <div class="form-group">
                                <label for="email" class="required">Email</label>
                                <input id="email" type="email" name="email" placeholder="example@email.com" required />
                            </div>
                            
                            <div class="form-group">
                                <label for="subject" class="required">Subject</label>
                                <input id="subject" type="text" name="subject" required />
                            </div>
                            
                            <div class="form-group">
                                <label for="message" class="required">Message</label>
                                <textarea id="message" name="message" rows="5" required></textarea>
                            </div>
                            
                            <div class="form-group" style="margin-bottom: 0;">
                                <button type="submit" class="submit" name="Submit">Send Message</button>
                            </div>
                        </form>
                    </div>
                </div>
				<div class="column-clear"></div>
            </div>
			<div class="clearfix"></div>
        </div>
    </div>
    
<div id="footer">
	<a href="index.php"><img src="images/footer-logo.jpg" alt="Dimple Star Transport" /></a>
	<p>&copy;Dimple Star Transport<br /></p>
</div>

</div>
</body>
</html>