<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<title>Dimple Star Transport</title>
<link rel="stylesheet" type="text/css" href="style/style.css" />
<link rel="icon" href="images/icon.ico" type="image/x-con">
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<style>
.auth-button {
    display: inline-block;
    padding: 8px 16px;
    background-color: #ECBD2F;
    color: white;
    text-decoration: none;
    border-radius: 4px;
    transition: background-color 0.3s ease;
    font-size: 14px;
}
.auth-button:hover {
    background-color: #D4A829;
    text-decoration: none;
}
.auth-text {
    color: white;
    margin-right: 10px;
}
.login-container {
    display: flex;
    align-items: center;
    justify-content: flex-end;
}
.slideshow-container {
    max-width: 1024px;
    position: relative;
    margin: auto;
}
.slide {
    display: none;
}
.slide img {
    width: 100%;
    height: auto;
}
.prev, .next {
    cursor: pointer;
    position: absolute;
    top: 50%;
    width: auto;
    padding: 16px;
    margin-top: -22px;
    color: white;
    font-weight: bold;
    font-size: 18px;
    transition: 0.6s ease;
    border-radius: 0 3px 3px 0;
    user-select: none;
    background-color: rgba(0,0,0,0.3);
}
.next {
    right: 0;
    border-radius: 3px 0 0 3px;
}
.prev:hover, .next:hover {
    background-color: rgba(0,0,0,0.8);
}
.dot-container {
    text-align: center;
    padding: 10px;
}
.dot {
    cursor: pointer;
    height: 10px;
    width: 10px;
    margin: 0 2px;
    background-color: #bbb;
    border-radius: 50%;
    display: inline-block;
    transition: background-color 0.6s ease;
}
.active, .dot:hover {
    background-color: #717171;
}
</style>
<script>
document.addEventListener('DOMContentLoaded', function() {
    let slideIndex = 1;
    showSlides(slideIndex);

    window.plusSlides = function(n) {
        showSlides(slideIndex += n);
    }

    window.currentSlide = function(n) {
        showSlides(slideIndex = n);
    }

    function showSlides(n) {
        let slides = document.getElementsByClassName("slide");
        let dots = document.getElementsByClassName("dot");
        
        if (n > slides.length) {slideIndex = 1}
        if (n < 1) {slideIndex = slides.length}
        
        for (let i = 0; i < slides.length; i++) {
            slides[i].style.display = "none";
        }
        for (let i = 0; i < dots.length; i++) {
            dots[i].className = dots[i].className.replace(" active", "");
        }
        
        slides[slideIndex-1].style.display = "block";
        dots[slideIndex-1].className += " active";
    }

    // Auto advance slides every 4 seconds
    setInterval(function() {
        plusSlides(1);
    }, 4000);
});
</script>
</head>
<body>
<div id="wrapper">
	<div id="header">
    <h1><a href="index.php"><img src="images/logo.png" class="logo" alt="Dimple Star Transport" /></a></h1>
        <ul id="mainnav">
			<li class="current"><a href="index.php">Home</a></li>
			<li><a href="about.php">About Us</a></li>
            <li><a href="terminal.php">Terminals</a></li>
			<li><a href="routeschedule.php">Routes / Schedules</a></li>
            <li><a href="contact.php">Contact</a></li>
			<li><a href="book.php">Book Now</a></li>
    	</ul>
	</div>
    <div id="content">
    	<div id="gallerycontainer">
			<div style="margin:10 auto; padding:30px 20px 20px 20px;">	
				<div class="login">
					<div class="login-container">
						<?php
							session_start();
							if(isset($_SESSION['email'])){
								$email = $_SESSION['email'];
								echo "<span class='auth-text'>Welcome, ". htmlspecialchars($email). "!</span>";
								echo "<a href='logout.php' class='auth-button'>Logout</a>";
							}
							if(empty($email)){
								echo "<a href='signlog.php' class='auth-button'>Sign Up / Login</a>";
							}?>
					</div>
				</div>
				<div class="slideshow-container">
                    <div class="slide">
                        <img src="slide/images/b1.png">
                    </div>
                    <div class="slide">
                        <img src="slide/images/b2.png">
                    </div>
                    <div class="slide">
                        <img src="slide/images/b3.png">
                    </div>
                    <div class="slide">
                        <img src="slide/images/b4.png">
                    </div>

                    <a class="prev" onclick="plusSlides(-1)">&#10094;</a>
                    <a class="next" onclick="plusSlides(1)">&#10095;</a>
                </div>
                <div class="dot-container">
                    <span class="dot" onclick="currentSlide(1)"></span>
                    <span class="dot" onclick="currentSlide(2)"></span>
                    <span class="dot" onclick="currentSlide(3)"></span>
                    <span class="dot" onclick="currentSlide(4)"></span>
                </div>
                <div style="margin-top: 20px;">
	Contact us at:
	<h2>0929 209 0712</h2>
	Block 1 lot 10, southpoint Subd.<br>
	Brgy Banay-Banay, Cabuyao, Laguna<br>

	<div id="right">
		<h3><?php include_once("php_includes/date_time.php"); ?></h3>
	</div>			
				<div class="column-clear"></div>
            </div>
				<div class="clearfix"></div>
        </div>
    </div>    
<div id="footer">
	<a href="index.php"><img src="images/footer-logo.jpg" alt="Dimple Star Transport" /></a>
	<p>&copy;Dimple Star Transport<br /></p>
</div>

</div>
</body>
</html>