<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<title>Dimple Star Transport</title>
<link rel="stylesheet" type="text/css" href="style/style.css" />
<link rel="icon" href="images/icon.ico" type="image/x-con">
</head>
<body>
<div id="wrapper">
	<div id="header">
    <h1><a href="index.php"><img src="images/logo.png" class="logo" alt="Dimple Star Transport" /></a></h1>
        <ul id="mainnav">
			<li><a href="index.php">Home</a></li>
			<li><a href="about.php">About Us</a></li>
            <li class="current"><a href="terminal.php">Terminals</a></li>
			<li><a href="routeschedule.php">Routes / Schedules</a></li>
            <li><a href="contact.php">Contact</a></li>
			<li><a href="book.php">Book Now</a></li>
    	</ul>
	</div>
    <div id="content">
    	<div id="gallerycontainer">
			<div style="margin:0 auto; padding:30px 20px 20px 20px; width:820px;">	
					<div class="login">
						<div id="right">
							<?php
								session_start();
								if(isset($_SESSION['email'])){
									$email = $_SESSION['email'];
									echo "Welcome,". $email. "!";
									echo "<a href='logout.php'>Logout</a>";
								}
								if(empty($email)){
									echo "<a href='signlog.php'></a>.";
								}?>
						</div>
					</div>
					<div id="right">
						<h3><?php include_once("php_includes/date_time.php"); ?></h3>
					</div>
        <div style="padding: 20px 0;">
            <h1 style="color: #333; margin-bottom: 30px; font-size: 24px; text-align: center;">Our Terminals</h1>
            
            <!-- España Terminal -->
            <div style="margin-bottom: 40px; background: #fff; border-radius: 8px; box-shadow: 0 2px 4px rgba(0,0,0,0.1); overflow: hidden;">
                <div style="padding: 20px; background: #ECBD2F;">
                    <h3 style="color: #fff; font-size: 20px; margin: 0;">España Terminal</h3>
                </div>
                <div style="padding: 20px;">
                    <div style="margin-bottom: 20px;">
                        <p style="color: #666; margin: 0; font-size: 16px;">
                            <strong style="color: #333;">Contact Numbers:</strong><br>
                            +63.02.985.1451<br>
                            +63.908.926.9163
                        </p>
                    </div>
                    <div style="border-radius: 4px; overflow: hidden; margin-bottom: 15px;">
                        <iframe width="100%" height="300" frameborder="0" scrolling="no" marginheight="0" marginwidth="0" 
                            style="border: none;"
                            src="https://maps.google.com.ph/maps?f=q&amp;source=s_q&amp;hl=en&amp;geocode=&amp;q=Dimple+Star,+836BAntipoloStSampaloc,521,Manila,&amp;aq=0&amp;oq=Metro+Manila&amp;sll=14.6125312,120.9948033&amp;sspn=0.011772,0.021136&amp;t=h&amp;ie=UTF8&amp;hq=&amp;hnear=Dimple+Star&amp;ll=14.6125312,120.9948033&amp;spn=0.011772,0.021136&amp;z=14&amp;output=embed">
                        </iframe>
                    </div>
                    <div style="text-align: right;">
                        <a href="https://www.google.com/maps/place/Dimple+Star/@14.6125312,120.9948033,770m/data=!3m2!1e3!4b1!4m2!3m1!1s0x3397b60300001d5d:0xd30645794daddf84?hl=en;z=14" 
                           style="color: #ECBD2F; text-decoration: none; font-size: 14px;" 
                           target="_blank">View Larger Map →</a>
                    </div>
                </div>
            </div>

            <!-- San Jose Terminal -->
            <div style="margin-bottom: 40px; background: #fff; border-radius: 8px; box-shadow: 0 2px 4px rgba(0,0,0,0.1); overflow: hidden;">
                <div style="padding: 20px; background: #ECBD2F;">
                    <h3 style="color: #fff; font-size: 20px; margin: 0;">San Jose Terminal</h3>
                </div>
                <div style="padding: 20px;">
                    <div style="margin-bottom: 20px;">
                        <p style="color: #666; margin: 0; font-size: 16px;">
                            <strong style="color: #333;">Contact Numbers:</strong><br>
                            +63.02.6684151<br>
                            +63.921.568.6449
                        </p>
                    </div>
                    <div style="border-radius: 4px; overflow: hidden; margin-bottom: 15px;">
                        <iframe width="100%" height="300" frameborder="0" scrolling="no" marginheight="0" marginwidth="0" 
                            style="border: none;"
                            src="https://maps.google.com.ph/maps?f=q&amp;source=s_q&amp;hl=en&amp;geocode=&amp;q=Dimple+Star+Transport,+BonifacioSt,SanJose,OccidentalMindoro,&amp;aq=0&amp;oq=&amp;sll=12.3540632,121.0618653&amp;sspn=0.011772,0.021136&amp;t=h&amp;ie=UTF8&amp;hq=&amp;hnear=Dimple+Star+Transport&amp;ll=12.3540632,121.0618653&amp;spn=0.011772,0.021136&amp;z=14&amp;output=embed">
                        </iframe>
                    </div>
                    <div style="text-align: right;">
                        <a href="https://www.google.com/maps/place/Dimple+Star+Transport/@14.6143711,120.9841972,458m/data=!3m2!1e3!4b1!4m2!3m1!1s0x3397b5fe6f7ebf6b:0xc34baa5ed38261eb?hl=en;z=14" 
                           style="color: #ECBD2F; text-decoration: none; font-size: 14px;" 
                           target="_blank">View Larger Map →</a>
                    </div>
                </div>
            </div>
        </div>
				
				<div id="right">
					<h3><?php include_once("php_includes/date_time.php"); ?></h3>
				</div>			
				<div class="column-clear"></div>
            </div>
				<div class="clearfix"></div>
        </div>
    </div>    		
	
<div id="footer">
	<a href="index.php"><img src="images/footer-logo.jpg" alt="Dimple Star Transport" /></a>
	<p>&copy;Dimple Star Transport<br /></p>
</div>

</div>
</body>
</html>