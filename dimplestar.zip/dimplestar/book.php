<!DOCTYPE html>
<?php
	include 'php_includes/connection.php';
	include 'php_includes/book.php';
?>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<title>Dimple Star Transport</title>
<link rel="stylesheet" type="text/css" href="style/style.css" />
<link rel="icon" href="images/icon.ico" type="image/x-con">
<style>
#gallerycontainer2 {
    background: #fff;
    padding: 20px;
    margin: 0 auto;
    min-height: 800px;
    width: 100%;
    position: relative;
}

.booking-container {
    width: 100%;
    max-width: 800px;
    margin: 0 auto;
    background: #fff;
    padding: 20px;
    box-sizing: border-box;
    position: relative;
}

.booking-table {
    width: 100%;
    background: #fff;
    margin: 20px auto;
    border-collapse: collapse;
    table-layout: fixed;
}

.booking-table h1 {
    color: #333;
    font-size: 24px;
    margin-bottom: 20px;
    border-bottom: 2px solid #ECBD2F;
    padding-bottom: 10px;
    text-align: center;
}

.booking-table td {
    padding: 15px;
    vertical-align: middle;
}

.booking-table td:first-child {
    width: 30%;
    font-weight: 500;
}

.booking-table select {
    width: 100%;
    padding: 8px;
    border: 1px solid #ddd;
    border-radius: 4px;
    font-size: 14px;
    color: #333;
    background: #fff;
    transition: border-color 0.3s;
}

.booking-table select:focus {
    border-color: #ECBD2F;
    outline: none;
}

.booking-table input[type="number"],
.booking-table input[type="text"] {
    width: 100%;
    padding: 8px;
    border: 1px solid #ddd;
    border-radius: 4px;
    font-size: 14px;
    transition: border-color 0.3s;
}

.booking-table input[type="number"]:focus,
.booking-table input[type="text"]:focus {
    border-color: #ECBD2F;
    outline: none;
}

.booking-table input[type="radio"] {
    margin-right: 5px;
}

.booking-table input[type="radio"] + span {
    margin-right: 15px;
    color: #333;
}

.submit-btn {
    background: #ECBD2F;
    color: white;
    padding: 15px;
    border: none;
    border-radius: 4px;
    font-size: 18px;
    font-weight: bold;
    cursor: pointer;
    transition: all 0.3s ease;
    display: block;
    text-align: center;
    max-width: 100%;
    margin: 0 auto;
}

.submit-btn:hover {
    background: #d4a618;
    transform: translateY(-1px);
    box-shadow: 0 2px 4px rgba(0,0,0,0.1);
}

.welcome-bar {
    background: #f8f8f8;
    padding: 10px;
    border-radius: 4px;
    margin-bottom: 20px;
    text-align: right;
    color: #666;
}

.welcome-bar h3 {
    margin: 0;
    font-size: 14px;
}

/* Calendar Styles */
.calendar {
    font-family: 'Trebuchet MS', Tahoma, Verdana, Arial, sans-serif;
    font-size: 0.9em;
    background-color: #fff;
    color: #333;
    border: 1px solid #ddd;
    border-radius: 4px;
    padding: 1.2em;
    width: auto;
    box-shadow: 0 2px 4px rgba(0,0,0,0.1);
}

.calendar .months {
    background-color: #ECBD2F;
    border: 1px solid #d4a618;
    border-radius: 4px;
    color: #FFF;
    padding: 0.5em;
    text-align: center;
    font-weight: bold;
}

.calendar td {
    padding: 8px;
    text-align: center;
}

.calendar td:hover {
    background: #f8f8f8;
    cursor: pointer;
}

.calendar .selected {
    background: #ECBD2F;
    color: white;
    border-radius: 4px;
}
</style>

</head>
<body>
<div id="wrapper">
	<div id="header">
    <h1><a href="index.php"><img src="images/logo.png" class="logo" alt="Dimple Star Transport" /></a></h1>
        <ul id="mainnav">
			<li><a href="index.php">Home</a></li>
			<li><a href="about.php">About Us</a></li>
            <li><a href="terminal.php">Terminals</a></li>
			<li><a href="routeschedule.php">Routes / Schedules</a></li>
            <li><a href="contact.php">Contact</a></li>
			<li class="current"><a href="book.php">Book Now</a></li>
    	</ul>
	</div>
    <div id="content">
    	<div id="gallerycontainer2" style="min-height: 800px;">
            <div class="booking-container">	
                    <div class="welcome-bar">
                        <h3><?php include_once("php_includes/date_time.php"); ?></h3>
                    </div>
		
                    <form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="post">
                        <table class="booking-table" border="0">
		<tr>
			<td colspan="4"> <h1> BOOK NOW!</h1><br> </td>
		</tr>
		<tr>
			<td  colspan="4"><input type="radio" name="way" value="2" onclick="document.getElementById('datepick2').disabled=false"> Two Way </input>
			<input type="radio" name="way" value="1" onclick="document.getElementById('datepick2').disabled=true" checked> One Way </input> </td>
		</tr> 
		<tr>
			<td colspan="2">Origin: </td>
			<td colspan="2">
				<select name="Origin">
					<option value="0">Select</option>
					<option value="San Lazaro">San Lazaro</option>
					<option value="Espana">Espana</option>
					<option value="Alabang">Alabang</option>
					<option value="Cabuyao">Cabuyao</option>
					<option value="Naujan">Naujan</option>
					<option value="Victoria">Victoria</option>
					<option value="Pinamalayan">Pinamalayan</option>
					<option value="Gloria">Gloria</option>
					<option value="Bongabong">Bongabong</option>
					<option value="Roxas">Roxas</option>
					<option value="Mansalay">Mansalay</option>
					<option value="Bulalacao">Bulalacao</option>
					<option value="Magsaysay">Magsaysay</option>
					<option value="San Jose">San Jose</option>
					<option value="Pola">Pola</option>
					<option value="Soccoro">Soccoro</option>
				</select>
			</td>
		</tr>
		<tr>
			<td colspan="2">Destination: </td>
			<td colspan="2">
				<select name="Destination">
					<option value="0">Select</option>
					<option value="San Lazaro">San Lazaro</option>
					<option value="Espana">Espana</option>
					<option value="Alabang">Alabang</option>
					<option value="Cabuyao">Cabuyao</option>
					<option value="Naujan">Naujan</option>
					<option value="Victoria">Victoria</option>
					<option value="Pinamalayan">Pinamalayan</option>
					<option value="Gloria">Gloria</option>
					<option value="Bongabong">Bongabong</option>
					<option value="Roxas">Roxas</option>
					<option value="Mansalay">Mansalay</option>
					<option value="Bulalacao">Bulalacao</option>
					<option value="Magsaysay">Magsaysay</option>
					<option value="San Jose">San Jose</option>
					<option value="Pola">Pola</option>
					<option value="Soccoro">Soccoro</option>
				</select>
			</td>
		</tr>
		<tr>
			<td colspan="2"> No.Of Passangers:</td>
			<td> <input type="number" name="no_of_pass" required />
			<!-- <td>
			<select name ="adult">
			<option value="0">Adult</option>
			<option value="1">1</option>
			<option value="2">2</option>
			<option value="3">3</option>
			<option value="4">4</option>
			<option value="5">5</option>
			<option value="6">6</option>
			</select>
			</td>
			
			<td>
			<select name ="child">
			<option value="0">Child</option>
			<option value="1">1</option>
			<option value="2">2</option>
			<option value="3">3</option>
			<option value="4">4</option>
			<option value="5">5</option>
			<option value="6">6</option>
			</select>
			</td>-->
		</tr>
		<tr>
		<td colspan="2"> Departure</td>
		<td colspan="2"><input id="datepick1" size="10" name="Departure" />
		</tr>
		<tr>
		<td colspan="2"> Return</td>
		<td colspan="2"><input id="datepick2" size="10"  name="Return" disabled/>
		</tr>
        <tr>
            <td colspan="2">Bus Type: </td>
            <td colspan="2">
                <select name="bustype">
                    <option value="0">Select</option>
                    <option value="Air Conditioned">Air Conditioned</option>
                    <option value="Ordinary">Ordinary</option>
                </select>
            </td>
        </tr>

        <tr>
            <td colspan="4" style="padding: 20px 0;">
                <button type="submit" name="submit" id="submit" class="submit-btn" style="width: 100%;">Book Now</button>
            </td>
        </tr>
    </table>
</form>
            </div>
            <div style="clear: both; margin-bottom: 40px;"></div>
        </div>
			<div class="clearfix"></div>
        </div>
		<div id="footer">
			<a href="index.php"><img src="images/footer-logo.jpg" alt="Dimple Star Transport" /></a>
			<p>&copy;Dimple Star Transport<br /></p>
		</div>
    </div>
</body>
		<style type="text/css">
			.calendar {
				font-family: 'Trebuchet MS', Tahoma, Verdana, Arial, sans-serif;
				font-size: 0.9em;
				background-color: #EEE;
				color: #333;
				border: 1px solid #DDD;
				-moz-border-radius: 4px;
				-webkit-border-radius: 4px;
				border-radius: 4px;
				padding: 1.2em;
				width: 11em;
			}
			
			.calendar .months {
				background-color: #F6AF3A;
				border: 1px solid #E78F08;
				-moz-border-radius: 4px;
				-webkit-border-radius: 4px;
				border-radius: 4px;
				color: #FFF;
				padding: 0.2em;
				text-align: center;
			}
			
			.calendar .prev-month,
			.calendar .next-month {
				padding: 0;
			}
			
			.calendar .prev-month {
				float: left;
			}
			
			.calendar .next-month {
				float: right;
			}
			
			.calendar .current-month {
				margin: 0 auto;
			}
			
			.calendar .months .prev-month,
			.calendar .months .next-month {
				color: #FFF;
				text-decoration: none;
				padding: 0 0.4em;
				-moz-border-radius: 4px;
				-webkit-border-radius: 4px;
				border-radius: 4px;
				cursor: pointer;
			}
			
			.calendar .months .prev-month:hover,
			.calendar .months .next-month:hover {
				background-color: #FDF5CE;
				color: #C77405;
			}
			
			.calendar table {
				border-collapse: collapse;
				padding: 0;
				font-size: 0.8em;
				width: 70%;
			}
			
			.calendar th {
				text-align: center;
			}
			
			.calendar td {
				text-align: right;
				padding: 1px;
				width: 14.3%;
			}
			
			.calendar td span {
				display: block;
				color: #1C94C4;
				background-color: #F6F6F6;
				border: 1px solid #CCC;
				text-decoration: none;
				padding: 0.2em;
				cursor: pointer;
			}
			
			.calendar td span:hover {
				color: #C77405;
				background-color: #FDF5CE;
				border: 1px solid #FBCB09;
			}
			
			.calendar td.today span {
				background-color: #FFF0A5;
				border: 1px solid #FED22F;
				color: #363636;
			}
		</style>


<script type="text/javascript" src="js/datepickr.js"></script>
		<script type="text/javascript">
						
			new datepickr('datepick1', {
				'dateFormat': '20y-m-d'
			});
            
            new datepickr('datepick2', {
				'dateFormat': '20y-m-d'
			});
			
			
		</script>
</html>