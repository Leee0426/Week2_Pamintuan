<?php
echo date("l") ." ". date("m-d-Y") . "<br>";
?>